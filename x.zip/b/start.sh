pkill python3
nohup python3 eps.py &