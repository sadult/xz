# Inline keyboard buttons
join_channel1 = "➕ Join First Channel"
join_channel2 = "➕ Join Second Channel"
follow_twitter = "➕ Follow Twitter"
btn_continue = "➡️ Continue"
done = "✅ Done"
confirm = "✅ Confirm"

# Keyboard buttons
balance = "💰 Balance"
withdraw = "📤 Withdraw"
account = "👤 Account"
referral = "🔗 Referral"
backtohome = "🏠 Back to home"
faq = "📚 FAQ"
back = "🔙 Back"
# share_with_friends = "⤴️ Share with friends"
check = '🔖 Check your withdrawal'
edit_information = '📝 Edit information'
edit_email = '📝 Edit Email'
edit_twitter = '📝 Edit Twitter username'
edit_wallet = '📝 Edit wallet address'
