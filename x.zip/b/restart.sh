kill $1
nohup python3 $2.py &
