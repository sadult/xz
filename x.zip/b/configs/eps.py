# Telegram
TOKEN = '5142918259:AAFvhO33_7DozYst2k-2mUHHgunw0zJhgMk'
BOT_USERNAME = 'Tronipay_Bot'
SUDO = 77365118

# Coin/Token
NETWORK = 'ethereum'
TOKEN_NAME = 'Tronipay'
SYMBOL = 'trp'
SYMBOL_UPPER = 'TRP'
CONTRACT = '0x9b1e1fc958b83e801d1342f9f9ba7da3a55ba1ef'
AIRDROP_SUPPLY = '2,000,000,000'
REGISTER_REWARD = '40000'
REFERRAL_REWARD = '8000'
CURRENT_PRICE = '0.001531'

# Channels
CHANNEL1 = 'tronipay_trp'
CHANNEL2 = 'Tronipay_Gp'
# CHANNEL3 = 'NPOWithdraw'
# CHANNEL3 = 'NPODeposit'

# Twitter account's
TWITTER = 'tronipay'
WITHDRAW_OPENING = '25 February'

# Our wallets
USDT_WALLET = 'TGZmhJxxX5yyUgEMmG5yFgHvroKGGVJRXf'
BNB_WALLET = 'bnb1drh6snd7m0szjl2wn9g4ukskfleh7w6hgzyu0q'
BUSD_WALLET = '0x1863fAB065c52D082aC54abcD913D83D6C9412b8'
TRX_WALLET =  'TGZmhJxxX5yyUgEMmG5yFgHvroKGGVJRXf'
